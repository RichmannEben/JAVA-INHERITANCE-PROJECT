
public class Answer {

	public static void main(String[] args) {
		Q1 m = new Q1();
	    SecondClass x = new SecondClass();
	    m.qmethod();
	    x.smethod();
	    x.qmethod();
	  }
	}	

