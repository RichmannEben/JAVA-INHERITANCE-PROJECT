
public class Q1 {
	public void qmethod(){
	    System.out.println("This is parent class");
	  }

}
