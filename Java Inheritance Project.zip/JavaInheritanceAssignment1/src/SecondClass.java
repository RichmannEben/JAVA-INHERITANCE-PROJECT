
public class SecondClass extends Q1 {
	public void smethod(){
	    System.out.println("This is child class");

}
}
