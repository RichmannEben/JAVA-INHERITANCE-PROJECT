
public class Employee extends Member{
 String specialization;
}
	class Manager extends Member{
		  String department;
}
	class Ans{
		  public static void main(String[] args){
		    Employee e = new Employee();
		    e.name = "ebenezer";
		    e.age = 35;
		    e.number = "zzzz****";
		    e.address = "accra";
		    e.salary = 1500;
		    e.specialization = "software";
		    
            Manager m = new Manager();
		  }
		}	
