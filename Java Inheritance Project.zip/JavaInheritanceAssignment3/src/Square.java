
public class Square extends Rectangle {
	 int side;
	  public Square(int s){
	    super(s,s);
	  }

}
